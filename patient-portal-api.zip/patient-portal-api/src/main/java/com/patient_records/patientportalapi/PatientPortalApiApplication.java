package com.patient_records.patientportalapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientPortalApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientPortalApiApplication.class, args);
	}

}
