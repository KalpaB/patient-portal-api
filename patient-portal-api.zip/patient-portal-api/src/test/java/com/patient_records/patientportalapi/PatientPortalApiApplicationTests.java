package com.patient_records.patientportalapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientPortalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
